-- phpMyAdmin SQL Dump
-- version 2.11.8.1deb5
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2009 年 08 月 04 日 10:25
-- 服务器版本: 5.0.51
-- PHP 版本: 5.2.6-1+lenny3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `chengde`
--
CREATE DATABASE `chengde` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `chengde`;

-- --------------------------------------------------------

--
-- 表的结构 `company_dept`
--

CREATE TABLE IF NOT EXISTS `company_dept` (
  `Id` int(10) NOT NULL auto_increment COMMENT 'ID',
  `Name` varchar(100) default NULL COMMENT '部门名称',
  `UpDeptId` int(10) default '0' COMMENT '上级部门',
  `EmployeeAmount` varchar(6) default NULL COMMENT '部门人数',
  `DeptOrder` int(4) default NULL COMMENT '部门排序',
  `DeptStatus` int(4) default '1' COMMENT '部门状态',
  `Remark` varchar(250) default NULL COMMENT '部门备注',
  PRIMARY KEY  (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='公司_部门' AUTO_INCREMENT=2 ;

--
-- 导出表中的数据 `company_dept`
--

INSERT INTO `company_dept` (`Id`, `Name`, `UpDeptId`, `EmployeeAmount`, `DeptOrder`, `DeptStatus`, `Remark`) VALUES
(1, '生产科', 0, NULL, NULL, 1, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `id` int(10) NOT NULL auto_increment COMMENT '序号',
  `EmpNo` bigint(10) NOT NULL default '0' COMMENT '员工编号',
  `DeptId` int(4) default '1' COMMENT '部门',
  `Realname` varchar(20) default NULL COMMENT '姓名',
  `Email` varchar(50) default NULL COMMENT '电子邮件',
  `Totp` varchar(20) default NULL COMMENT '职称',
  `BZ` varchar(20) default NULL COMMENT '编制',
  `Sex` int(2) default NULL COMMENT '性别',
  `Insurance` varchar(200) default NULL COMMENT '保险',
  `Birthday` date default NULL COMMENT '出生日期',
  `Nativeplace` varchar(50) default NULL COMMENT '籍贯',
  `RPRType` int(2) default '1' COMMENT '户口类型',
  `Nation` varchar(20) default NULL COMMENT '民族',
  `Health` varchar(100) default NULL COMMENT '健康状况',
  `IDCard` varchar(20) default NULL COMMENT '身份证号码',
  `Polity` varchar(20) default NULL COMMENT '政治面貌',
  `Weeding` varchar(10) default NULL COMMENT '婚姻状况',
  `School` varchar(100) default NULL COMMENT '毕业院校',
  `GraduteDate` date default NULL COMMENT '毕业时间',
  `Degree` varchar(40) default NULL COMMENT '文化程度',
  `Speciality` varchar(40) default NULL COMMENT '专业特长',
  `Interest` varchar(100) default NULL COMMENT '特长爱好',
  `Address` varchar(100) default NULL COMMENT '现住址',
  `Tel` varchar(20) default NULL COMMENT '现住址联系电话',
  `Mobile` varchar(20) default NULL COMMENT '手机',
  `RPRAddress` varchar(20) default NULL COMMENT '户口所在地',
  `RPRTel` varchar(20) default NULL COMMENT '所在地电话',
  `ParticipateDate` date default NULL COMMENT '进厂时间',
  `Photo` varchar(100) default NULL,
  `Remark` varchar(250) default NULL COMMENT '备注',
  `WorkTel` varchar(20) default NULL COMMENT '办公电话',
  `QQ` int(15) default NULL COMMENT 'QQ号',
  `MSN` varchar(50) default NULL,
  `selfDesc` varchar(250) default NULL COMMENT '自我描述',
  `ZhiChen` varchar(20) default NULL COMMENT '职称',
  `ZhiChenDate` date default NULL COMMENT '职称取得时间',
  `BianZhi` varchar(20) default NULL COMMENT '编制',
  `DisabilityIdcard` varchar(50) default NULL COMMENT '残疾证编号',
  `ContractSignDate` date default NULL COMMENT '合同签订日期',
  `ContractMatureDate` date default NULL COMMENT '合同到期日期',
  `ContractRemark` varchar(250) default NULL COMMENT '合同签订备注',
  `InfoStatus` int(11) default '1' COMMENT '资料状态',
  `WorkStatus` int(4) default '0' COMMENT '员工状态0：在职；2：试用期；3：即将离职；100：退休；',
  `RewardsAndPunishiment` varchar(250) default NULL COMMENT '奖惩记录',
  `JobChanges` varchar(250) default NULL COMMENT '工作变动记录',
  `WorkTrain` varchar(250) default NULL COMMENT '培训记录',
  `Recognizor` varchar(250) default NULL COMMENT '担保记录',
  `Physical` varchar(250) default NULL COMMENT '体检记录',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='员工表_主表' AUTO_INCREMENT=4 ;

--
-- 导出表中的数据 `employee`
--

INSERT INTO `employee` (`id`, `EmpNo`, `DeptId`, `Realname`, `Email`, `Totp`, `BZ`, `Sex`, `Insurance`, `Birthday`, `Nativeplace`, `RPRType`, `Nation`, `Health`, `IDCard`, `Polity`, `Weeding`, `School`, `GraduteDate`, `Degree`, `Speciality`, `Interest`, `Address`, `Tel`, `Mobile`, `RPRAddress`, `RPRTel`, `ParticipateDate`, `Photo`, `Remark`, `WorkTel`, `QQ`, `MSN`, `selfDesc`, `ZhiChen`, `ZhiChenDate`, `BianZhi`, `DisabilityIdcard`, `ContractSignDate`, `ContractMatureDate`, `ContractRemark`, `InfoStatus`, `WorkStatus`, `RewardsAndPunishiment`, `JobChanges`, `WorkTrain`, `Recognizor`, `Physical`) VALUES
(1, 0, 1, '姚俊刚', '', NULL, NULL, NULL, NULL, NULL, '', 1, NULL, NULL, NULL, NULL, '未填', '', NULL, '', '', '', '', '', '', '', '', NULL, NULL, NULL, '', NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL),
(2, 0, 1, '管理员', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL),
(3, 0, 1, '印版管理员', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `employee_family`
--

CREATE TABLE IF NOT EXISTS `employee_family` (
  `ID` int(10) NOT NULL auto_increment COMMENT '编号',
  `EID` int(10) default NULL COMMENT '员工表编号',
  `Name` varchar(20) default NULL COMMENT '家庭成员姓名',
  `Relation` varchar(20) default NULL COMMENT '与本人关系',
  `Polity` varchar(20) default NULL COMMENT '政治面貌',
  `Company` varchar(80) default NULL COMMENT '工作单位',
  `Job` varchar(50) default NULL COMMENT '职务',
  `FamilyOrder` int(4) default NULL COMMENT '顺序',
  PRIMARY KEY  (`ID`),
  KEY `FK9AFAD615AD86888` (`EID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='员工表_家庭成员' AUTO_INCREMENT=1 ;

--
-- 导出表中的数据 `employee_family`
--


-- --------------------------------------------------------

--
-- 表的结构 `employee_resume`
--

CREATE TABLE IF NOT EXISTS `employee_resume` (
  `ID` int(8) NOT NULL auto_increment,
  `EID` int(10) default NULL COMMENT '员工表ID',
  `StartTime` date default NULL COMMENT '开始时间',
  `EndTime` date default NULL COMMENT '结束时间',
  `Company` varchar(80) default NULL COMMENT '单位',
  `Job` varchar(50) default NULL COMMENT '工作',
  `ResumeOrder` int(4) default NULL COMMENT '顺序',
  PRIMARY KEY  (`ID`),
  KEY `FKAFB042DEAD86888` (`EID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='员工表_个人简历' AUTO_INCREMENT=1 ;

--
-- 导出表中的数据 `employee_resume`
--


-- --------------------------------------------------------

--
-- 表的结构 `plate`
--

CREATE TABLE IF NOT EXISTS `plate` (
  `id` int(11) NOT NULL auto_increment,
  `startTime` datetime default NULL,
  `lastChangeTime` datetime default NULL,
  `startMan` varchar(50) default NULL COMMENT '开单人',
  `lastChangeMan` varchar(50) default NULL COMMENT '最后修改人',
  `viewTimes` int(10) default NULL COMMENT '查看次数',
  `InputDate` datetime default NULL COMMENT '入库时间',
  `LastUseDate` datetime default NULL COMMENT '最后使用时间',
  `ExpDate` timestamp NULL default CURRENT_TIMESTAMP COMMENT '过期时间',
  `DanAnNo` varchar(50) default NULL,
  `PName` varchar(50) default NULL,
  `PlateNo` varchar(20) default NULL COMMENT '版号',
  `PlateLength` double default NULL COMMENT '版长',
  `PlateWidth` double default NULL COMMENT '版周',
  `PlateAmount` int(10) default NULL COMMENT '支数',
  `PlateShare` varchar(50) default NULL COMMENT '共用版',
  `PlateAddress` varchar(100) default NULL COMMENT '位置编号',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=8 ;

--
-- 导出表中的数据 `plate`
--

INSERT INTO `plate` (`id`, `startTime`, `lastChangeTime`, `startMan`, `lastChangeMan`, `viewTimes`, `InputDate`, `LastUseDate`, `ExpDate`, `DanAnNo`, `PName`, `PlateNo`, `PlateLength`, `PlateWidth`, `PlateAmount`, `PlateShare`, `PlateAddress`) VALUES
(1, NULL, NULL, NULL, NULL, 2, '2009-04-20 00:00:00', '2009-04-20 00:00:00', '2010-04-20 00:00:00', '', '爱洋珍珠鱿鱼', '3019391', 62, NULL, 7, '0', ''),
(2, NULL, NULL, NULL, NULL, 3, '2007-10-29 00:00:00', '2008-02-10 00:00:00', '2009-02-10 00:00:00', '', '希波羊肉串自然味400g', '201216', 78, NULL, 9, '0', '0'),
(3, NULL, NULL, NULL, NULL, 3, '2009-04-01 00:00:00', '2009-04-02 00:00:00', '2010-04-20 00:00:00', '', '正清和花芽', '3018779', 68, NULL, 6, '3018778', ''),
(4, NULL, NULL, NULL, NULL, 4, '2009-04-01 00:00:00', '2009-04-02 00:00:00', '2010-04-20 00:00:00', '', '正清和巴山芽', '3018778', 68, NULL, 8, '0', ''),
(5, NULL, NULL, NULL, NULL, 3, '2009-04-02 00:00:00', '2009-04-03 00:00:00', '2010-04-20 00:00:00', '', '味全青豆鸡肉烧麦', '3018791', 78, NULL, 7, '3018790', ''),
(6, NULL, NULL, NULL, NULL, 4, '2009-04-02 00:00:00', '2009-04-03 00:00:00', '2010-04-20 00:00:00', '', '味全香菇猪肉烧麦', '3018790', 78, NULL, 9, '0', ''),
(7, NULL, NULL, NULL, NULL, 43, '2009-04-03 00:00:00', '2009-04-04 00:00:00', '2010-04-20 00:00:00', '', '味全鲜虾猪肉烧麦', '3018792', 78, NULL, 7, '3018790', '');

-- --------------------------------------------------------

--
-- 表的结构 `plate_use_log`
--

CREATE TABLE IF NOT EXISTS `plate_use_log` (
  `id` int(11) NOT NULL auto_increment,
  `plateId` int(11) default NULL COMMENT '版库Id',
  `useTime` datetime default NULL COMMENT '使用时间',
  `inputMan` varchar(50) default NULL COMMENT '输入人',
  `pressAmount` int(11) default NULL COMMENT '印数',
  `useOrder` int(5) default NULL COMMENT '顺序',
  `remark` varchar(250) default NULL COMMENT '备注',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='版使用记录' AUTO_INCREMENT=1 ;

--
-- 导出表中的数据 `plate_use_log`
--


-- --------------------------------------------------------

--
-- 表的结构 `role`
--

CREATE TABLE IF NOT EXISTS `role` (
  `id` int(8) NOT NULL auto_increment,
  `DeptId` int(11) default '1' COMMENT '部门ID',
  `RName` varchar(50) default NULL COMMENT '角色名称',
  `RDescribe` varchar(100) default NULL COMMENT '角色描述',
  `RRemark` varchar(250) default NULL COMMENT '备注',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='角色表' AUTO_INCREMENT=2 ;

--
-- 导出表中的数据 `role`
--

INSERT INTO `role` (`id`, `DeptId`, `RName`, `RDescribe`, `RRemark`) VALUES
(1, 1, '印版库管理员', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `roles_functions`
--

CREATE TABLE IF NOT EXISTS `roles_functions` (
  `RoleId` int(11) NOT NULL COMMENT '角色ID',
  `FunctionId` int(11) NOT NULL COMMENT '系统功能ID'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='角色_系统功能关系表';

--
-- 导出表中的数据 `roles_functions`
--

INSERT INTO `roles_functions` (`RoleId`, `FunctionId`) VALUES
(1, 3),
(1, 4);

-- --------------------------------------------------------

--
-- 表的结构 `system_functions`
--

CREATE TABLE IF NOT EXISTS `system_functions` (
  `id` int(11) NOT NULL auto_increment,
  `ModuleId` int(11) default NULL COMMENT '所属模块',
  `Name` varchar(150) default NULL,
  `Remark` varchar(250) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='系统功能表' AUTO_INCREMENT=5 ;

--
-- 导出表中的数据 `system_functions`
--

INSERT INTO `system_functions` (`id`, `ModuleId`, `Name`, `Remark`) VALUES
(1, 1, 'System-Basic', '系统设置'),
(2, 2, 'HR-Basic', '人事管理'),
(3, 3, 'Plate-Basic', '印版库管理'),
(4, 1, 'System-Login', '登陆系统');

-- --------------------------------------------------------

--
-- 表的结构 `system_modules`
--

CREATE TABLE IF NOT EXISTS `system_modules` (
  `id` int(11) NOT NULL auto_increment COMMENT 'ID',
  `Name` varchar(50) default NULL COMMENT '名称',
  `ChineseName` varchar(100) default NULL COMMENT '中文名称',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='系统模块表' AUTO_INCREMENT=4 ;

--
-- 导出表中的数据 `system_modules`
--

INSERT INTO `system_modules` (`id`, `Name`, `ChineseName`) VALUES
(1, 'SystemManagement', '系统设置管理'),
(2, 'HumanResoursManage', '人力资源管理'),
(3, 'PlateManage', '印版库管理');

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(8) NOT NULL auto_increment COMMENT 'ID',
  `EID` int(8) default NULL COMMENT '职工表ID',
  `Username` varchar(20) default NULL COMMENT '用户名',
  `Password` varchar(128) default NULL COMMENT '密码',
  `LastLoginIp` varchar(16) default NULL COMMENT '最后登录IP',
  `LastLoginTime` timestamp NULL default CURRENT_TIMESTAMP COMMENT '最后登录时间',
  `Url` varchar(50) default NULL COMMENT '用户登录后默认转向的Url',
  `UserType` varchar(10) default 'user' COMMENT '用户类型',
  `Remark` varchar(255) default NULL COMMENT '备注',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='系统用户表' AUTO_INCREMENT=4 ;

--
-- 导出表中的数据 `user`
--

INSERT INTO `user` (`id`, `EID`, `Username`, `Password`, `LastLoginIp`, `LastLoginTime`, `Url`, `UserType`, `Remark`) VALUES
(1, 1, 'y109', '9cfea5badccd277c653e903d8cc1abee', NULL, '2009-06-02 08:37:47', '/Plate/PlateAdmin.action', 'Admin', NULL),
(2, 2, 'admin', '7fef6171469e80d32c0559f88b377245', NULL, '2009-04-20 10:59:00', '/Plate/PlateAdmin.action', 'Admin', NULL),
(3, 3, 'plate', '769da256fbedfbc1b6124beeb8da3a61', NULL, '2009-05-16 16:40:25', '/Plate/PlateAdmin.action', 'user', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `users_roles`
--

CREATE TABLE IF NOT EXISTS `users_roles` (
  `UserId` int(11) NOT NULL COMMENT '用户ID',
  `RoleId` int(11) NOT NULL COMMENT '角色ID'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户_角色关系表';

--
-- 导出表中的数据 `users_roles`
--

INSERT INTO `users_roles` (`UserId`, `RoleId`) VALUES
(2, 1),
(1, 1),
(3, 1);
